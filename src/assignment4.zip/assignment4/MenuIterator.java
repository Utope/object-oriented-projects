package assignment4;

public interface MenuIterator {
	public boolean hasNext();
	public MenuItem next();
}
