package assignment4;

import java.util.ArrayList;

public class Menu {
	
	public static final int APPETIZERS = 1;
	public static final int MAIN_DISH = 2;
	public static final int DESSERT = 3;
	
	public static final boolean HEART_HEALTHY = true;
	public static final boolean NOT_HEART_HEALTHY = false;
	
	private ArrayList<MenuItem> items;
	
	public Menu() {
		items = new ArrayList<>();
	}
	
	public void add(MenuItem item) {
		items.add(item);
	}
	
	public void delete(MenuIterator it) {
		while(it.hasNext()) {
			Object obj = it.next();
			if(obj instanceof MenuItem) {
				items.remove(obj);
			}
		}
	}
	
	public MenuIterator AllItemsIterator(){
		return new AllItemsIterator();
	}
	
	public MenuIterator ItemIterator(int category){
		return new ItemIterator(category);
	}
	
	public MenuIterator HeartHealthyIterator(boolean heartHealthy){
		return new HeartHealthyIterator(heartHealthy);
	}
	
	public MenuIterator PriceIterator(float highestPrice){
		return new PriceIterator(highestPrice);
	}
	
	
	
	// ITERATOR LIST //
	
	class AllItemsIterator implements MenuIterator{
		int counter;
		
		public AllItemsIterator() {
			this.counter = 0;
		}
		
		@Override
		public boolean hasNext() {
			if(counter < items.size()) {
				return true;
			}else {
				return false;
			}
		}

		@Override
		public MenuItem next() {
			return items.get(counter++);
		}
		
	}
	
	class ItemIterator implements MenuIterator{
		
		int counter;
		int category;
		
		public ItemIterator(int category) {
			this.counter = 0;
			this.category = category;
		}
		
		@Override
		public boolean hasNext() {
			while(counter < items.size()) {
				if(items.get(counter).getCategory() == category) {
					return true;
				}else {
					counter++;
				}
			}
			return false;
		}

		@Override
		public MenuItem next() {
			if(hasNext()) {
				return items.get(counter++);
			}
			return null;
		}
		
	}
	
	class HeartHealthyIterator implements MenuIterator{
		
		int counter;
		boolean isHealthy;
		
		public HeartHealthyIterator(boolean heartHealthy){
			this.counter = 0;
			this.isHealthy = heartHealthy;
		}
		@Override
		public boolean hasNext() {
			while(counter < items.size()) {
				if(items.get(counter).isHeartHealthy() == isHealthy) {
					return true;
				}else {
					counter++;
				}
			}
			return false;
		}

		@Override
		public MenuItem next() {
			if(hasNext()) {
				return items.get(counter++);
			}
			return null;
		}
		
	}
	
	class PriceIterator implements MenuIterator{
		
		int counter;
		float highestPrice;
		
		public PriceIterator(float highestPrice) {
			this.counter = 0;
			this.highestPrice = highestPrice;
		}
		
		@Override
		public boolean hasNext() {
			while(counter < items.size()) {
				if(items.get(counter).getPrice() < highestPrice) {
					return true;
				}else {
					counter++;
				}
			}
			return false;
		}

		@Override
		public MenuItem next() {
			if(hasNext()) {
				return items.get(counter++);
			}
			return null;
		}
		
	}
}
